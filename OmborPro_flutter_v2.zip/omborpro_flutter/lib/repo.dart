import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'db.dart';
import 'models.dart';
import 'util.dart';

/// Barcha ma’lumotlar va biznes-qoidalar shu yerda.
/// Har bir amal bitta tranzaksiyada bajariladi (xato bo‘lsa — hammasi bekor qilinadi).
/// `opId` takroriy bosishdan himoya qiladi: bir xil opId bilan amal faqat bir marta bajariladi.
class Repo extends ChangeNotifier {
  Database? _db;
  Database get db => _db!;

  List<Product> products = [];
  List<Movement> movements = [];
  List<FinanceEntry> finance = [];
  List<Party> parties = [];
  List<Debt> debts = [];
  List<Payment> payments = [];
  ThemeMode themeMode = ThemeMode.system;
  final Map<String, Party> _partyMap = {};

  Future<void> init({String? path}) async {
    _db = await openAppDb(path: path);
    await reload();
  }

  Future<void> reload() async {
    products = (await db.query('products', orderBy: 'name COLLATE NOCASE')).map(Product.fromMap).toList();
    movements = (await db.query('movements', orderBy: 'ts DESC')).map(Movement.fromMap).toList();
    finance = (await db.query('finance', orderBy: 'ts DESC')).map(FinanceEntry.fromMap).toList();
    parties = (await db.query('parties', orderBy: 'name COLLATE NOCASE')).map(Party.fromMap).toList();
    payments = (await db.query('payments', orderBy: 'ts DESC')).map(Payment.fromMap).toList();
    debts = (await db.rawQuery(
            'SELECT d.*, COALESCE((SELECT SUM(amount) FROM payments WHERE debt_id = d.id), 0) AS paid '
            'FROM debts d ORDER BY d.ts'))
        .map(Debt.fromMap)
        .toList();
    _partyMap
      ..clear()
      ..addEntries(parties.map((x) => MapEntry(x.id, x)));
    final t = await db.query('settings', where: "key = 'theme'", limit: 1);
    final v = t.isEmpty ? 'system' : t.first['value'];
    themeMode = v == 'light' ? ThemeMode.light : v == 'dark' ? ThemeMode.dark : ThemeMode.system;
    notifyListeners();
  }

  // ---------- so‘rovlar ----------
  Party? partyById(String id) => _partyMap[id];
  List<Party> partiesOf(PartyType t) => parties.where((p) => p.type == t).toList();
  List<Debt> debtsOf(String partyId) => debts.where((d) => d.partyId == partyId).toList();
  int balanceOf(String partyId) => debtsOf(partyId).fold(0, (s, d) => s + max(d.remaining, 0));
  List<Payment> paymentsOf(String debtId) => payments.where((p) => p.debtId == debtId).toList();

  int _owed(PartyType t) =>
      debts.where((d) => partyById(d.partyId)?.type == t).fold(0, (s, d) => s + max(d.remaining, 0));
  int get customersOwe => _owed(PartyType.customer);
  int get weOwe => _owed(PartyType.supplier);
  int overdueCount(PartyType t) => debts.where((d) => d.isOverdue && partyById(d.partyId)?.type == t).length;

  // ---------- ichki yordamchilar ----------
  Future<bool> _seen(DatabaseExecutor tx, String table, String opId) async {
    final r = await tx.query(table, columns: ['id'], where: 'op_id = ?', whereArgs: [opId], limit: 1);
    return r.isNotEmpty;
  }

  Future<Map<String, Object?>> _prod(DatabaseExecutor tx, String id) async {
    final r = await tx.query('products', where: 'id = ?', whereArgs: [id], limit: 1);
    if (r.isEmpty) throw AppError('Mahsulot topilmadi.');
    return r.first;
  }

  Future<String> _mov(DatabaseExecutor tx, String opId, MovementKind kind, Map<String, Object?> prod, double delta,
      int unitPrice, int unitCost, String note, DateTime ts) async {
    final id = newId();
    await tx.insert('movements', {
      'id': id, 'op_id': opId, 'ts': ts.millisecondsSinceEpoch, 'kind': kind.name,
      'product_id': prod['id'], 'product_name': prod['name'], 'delta': delta,
      'unit_price': unitPrice, 'unit_cost': unitCost, 'note': note,
    });
    return id;
  }

  Future<void> _fin(DatabaseExecutor tx, String opId, FinanceKind kind, int amount, String title, String note, DateTime ts) =>
      tx.insert('finance', {
        'id': newId(), 'op_id': opId, 'ts': ts.millisecondsSinceEpoch, 'kind': kind.name,
        'amount': amount, 'title': title, 'note': note,
      });

  Future<void> _debt(DatabaseExecutor tx, String partyId, int amount, DateTime? due, String note, String? movementId,
      DateTime ts) =>
      tx.insert('debts', {
        'id': newId(), 'party_id': partyId, 'ts': ts.millisecondsSinceEpoch, 'due': due?.millisecondsSinceEpoch,
        'amount': amount, 'note': note, 'movement_id': movementId,
      });

  Future<T> _run<T>(Future<T> Function(Transaction tx) body) async {
    final r = await db.transaction(body);
    await reload();
    return r;
  }

  void _needQty(double q) {
    if (q <= 0) throw AppError('Miqdor 0 dan katta bo‘lishi kerak.');
  }

  void _needStock(Map<String, Object?> row, double q) {
    final have = (row['qty'] as num).toDouble();
    if (q > have + 1e-9) {
      throw AppError('Omborda yetarli mahsulot yo‘q. Mavjud: ${qtyText(have)} ${row['unit']}.');
    }
  }

  // ---------- mahsulotlar ----------
  Future<void> _checkBarcode(DatabaseExecutor tx, String barcode, String id) async {
    if (barcode.isEmpty) return;
    final r = await tx.query('products', columns: ['id'], where: 'barcode = ? AND id != ?', whereArgs: [barcode, id], limit: 1);
    if (r.isNotEmpty) throw AppError('Bu shtrix-kod boshqa mahsulotda mavjud.');
  }

  Map<String, Object?> _prodMap(Product p) => {
        'name': p.name.trim(), 'barcode': p.barcode.trim(), 'category': p.category.trim(), 'cost': p.cost,
        'price': p.price, 'unit': p.unit, 'min_qty': p.minQty, 'supplier': p.supplier.trim(), 'note': p.note, 'image': p.image,
      };

  Future<void> createProduct(Product p, double openingQty, {String? opId}) async {
    if (p.name.trim().isEmpty) throw AppError('Mahsulot nomini kiriting.');
    if (openingQty < 0) throw AppError('Boshlang‘ich qoldiq manfiy bo‘lishi mumkin emas.');
    final op = opId ?? newId();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      await _checkBarcode(tx, p.barcode.trim(), p.id);
      await tx.insert('products', {'id': p.id, ..._prodMap(p), 'qty': openingQty, 'created': DateTime.now().millisecondsSinceEpoch});
      if (openingQty > 0) {
        final row = await _prod(tx, p.id);
        await _mov(tx, op, MovementKind.opening, row, openingQty, p.cost, p.cost, 'Boshlang‘ich qoldiq', DateTime.now());
      }
    });
  }

  Future<void> updateProduct(Product p) async {
    if (p.name.trim().isEmpty) throw AppError('Mahsulot nomini kiriting.');
    await _run((tx) async {
      await _checkBarcode(tx, p.barcode.trim(), p.id);
      await tx.update('products', _prodMap(p), where: 'id = ?', whereArgs: [p.id]);
    });
  }

  /// Mahsulot o‘chiriladi, tarix (nomi bilan) saqlanib qoladi.
  Future<void> deleteProduct(String id) => _run((tx) async {
        await tx.update('movements', {'product_id': null}, where: 'product_id = ?', whereArgs: [id]);
        await tx.delete('products', where: 'id = ?', whereArgs: [id]);
      });

  // ---------- ombor amallari ----------
  Future<void> receive(Product p, double qty, int unitCost,
      {MovementKind kind = MovementKind.purchase, String note = '', String? opId, int? paid, String? partyId, DateTime? due}) async {
    _needQty(qty);
    if (unitCost < 0) throw AppError('Narx manfiy bo‘lishi mumkin emas.');
    final op = opId ?? newId();
    final now = DateTime.now();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      final row = await _prod(tx, p.id);
      final oldQty = max((row['qty'] as num).toDouble(), 0.0);
      final newCost = (((row['cost'] as num) * oldQty + unitCost * qty) / (oldQty + qty)).round();
      await tx.update('products', {'qty': (row['qty'] as num).toDouble() + qty, 'cost': newCost},
          where: 'id = ?', whereArgs: [p.id]);
      final mid = await _mov(tx, op, kind, row, qty, unitCost, unitCost, note, now);
      if (kind == MovementKind.purchase) {
        final total = (qty * unitCost).round();
        final paidAmt = min(max(paid ?? total, 0), total);
        if (paidAmt > 0) await _fin(tx, '$op:cash', FinanceKind.purchaseExpense, paidAmt, p.name, note, now);
        if (total - paidAmt > 0) {
          if (partyId == null) throw AppError('Qarzga olish uchun yetkazib beruvchini tanlang.');
          await _debt(tx, partyId, total - paidAmt, due, 'Xarid: ${p.name}', mid, now);
        }
      }
    });
  }

  Future<void> sell(Product p, double qty, int unitPrice,
      {String note = '', String? opId, int? paid, String? partyId, DateTime? due}) async {
    _needQty(qty);
    if (unitPrice < 0) throw AppError('Narx manfiy bo‘lishi mumkin emas.');
    final op = opId ?? newId();
    final now = DateTime.now();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      final row = await _prod(tx, p.id);
      _needStock(row, qty);
      final total = (qty * unitPrice).round();
      final paidAmt = min(max(paid ?? total, 0), total);
      if (total - paidAmt > 0 && partyId == null) throw AppError('Qarzga sotish uchun mijozni tanlang.');
      await tx.update('products', {'qty': max(0.0, (row['qty'] as num).toDouble() - qty)}, where: 'id = ?', whereArgs: [p.id]);
      final mid = await _mov(tx, op, MovementKind.sale, row, -qty, unitPrice, (row['cost'] as num).toInt(), note, now);
      if (paidAmt > 0) await _fin(tx, '$op:cash', FinanceKind.saleIncome, paidAmt, p.name, note, now);
      if (total - paidAmt > 0) await _debt(tx, partyId!, total - paidAmt, due, 'Sotuv: ${p.name}', mid, now);
    });
  }

  Future<void> returnItem(Product p, double qty, int unitPrice, {String note = '', String? opId}) async {
    _needQty(qty);
    if (unitPrice < 0) throw AppError('Narx manfiy bo‘lishi mumkin emas.');
    final op = opId ?? newId();
    final now = DateTime.now();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      final row = await _prod(tx, p.id);
      await tx.update('products', {'qty': (row['qty'] as num).toDouble() + qty}, where: 'id = ?', whereArgs: [p.id]);
      await _mov(tx, op, MovementKind.saleReturn, row, qty, unitPrice, (row['cost'] as num).toInt(), note, now);
      await _fin(tx, '$op:cash', FinanceKind.returnRefund, (qty * unitPrice).round(), p.name, note, now);
    });
  }

  Future<void> writeOff(Product p, double qty, {String note = '', String? opId}) async {
    _needQty(qty);
    final op = opId ?? newId();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      final row = await _prod(tx, p.id);
      _needStock(row, qty);
      await tx.update('products', {'qty': max(0.0, (row['qty'] as num).toDouble() - qty)}, where: 'id = ?', whereArgs: [p.id]);
      final c = (row['cost'] as num).toInt();
      await _mov(tx, op, MovementKind.writeOff, row, -qty, c, c, note, DateTime.now());
    });
  }

  Future<void> adjust(Product p, double newQty, {String note = '', String? opId}) async {
    if (newQty < 0) throw AppError('Qoldiq manfiy bo‘lishi mumkin emas.');
    final op = opId ?? newId();
    await _run((tx) async {
      if (await _seen(tx, 'movements', op)) return;
      final row = await _prod(tx, p.id);
      final delta = newQty - (row['qty'] as num).toDouble();
      if (delta.abs() < 1e-9) return;
      await tx.update('products', {'qty': newQty}, where: 'id = ?', whereArgs: [p.id]);
      final c = (row['cost'] as num).toInt();
      await _mov(tx, op, MovementKind.adjustment, row, delta, c, c, note, DateTime.now());
    });
  }

  // ---------- pul (boshqa kirim/xarajat) ----------
  Future<void> addOther(FinanceKind kind, int amount, String title, {String note = '', String? opId}) async {
    if (!kind.isManual) throw AppError('Bu tur qo‘lda kiritilmaydi.');
    if (amount <= 0) throw AppError('Summani to‘g‘ri kiriting.');
    final op = opId ?? newId();
    await _run((tx) async {
      if (await _seen(tx, 'finance', op)) return;
      await _fin(tx, op, kind, amount, title, note, DateTime.now());
    });
  }

  Future<void> deleteOther(FinanceEntry e) async {
    if (!e.kind.isManual) throw AppError('Bu yozuvni o‘chirib bo‘lmaydi.');
    await _run((tx) => tx.delete('finance', where: 'id = ?', whereArgs: [e.id]));
  }

  // ---------- mijozlar / yetkazib beruvchilar ----------
  Future<Party> addParty(String name, String phone, PartyType type, {String note = ''}) async {
    if (name.trim().isEmpty) throw AppError('Ismni kiriting.');
    final party = Party(id: newId(), name: name.trim(), phone: phone.trim(), note: note, type: type);
    await _run((tx) => tx.insert('parties', {
          'id': party.id, 'name': party.name, 'phone': party.phone, 'type': type.name, 'note': note,
          'created': DateTime.now().millisecondsSinceEpoch,
        }));
    return party;
  }

  Future<void> updateParty(Party p) async {
    if (p.name.trim().isEmpty) throw AppError('Ismni kiriting.');
    await _run((tx) => tx.update('parties', {'name': p.name.trim(), 'phone': p.phone.trim(), 'note': p.note},
        where: 'id = ?', whereArgs: [p.id]));
  }

  Future<void> deleteParty(String id) => _run((tx) async {
        final n = Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM debts WHERE party_id = ?', [id])) ?? 0;
        if (n > 0) throw AppError('Qarz tarixi bor — o‘chirib bo‘lmaydi.');
        await tx.delete('parties', where: 'id = ?', whereArgs: [id]);
      });

  // ---------- qarzlar ----------
  /// Qo‘lda qarz yozish (sotuv/xarid bilan bog‘lanmagan).
  Future<void> addDebt(String partyId, int amount, {DateTime? due, String note = ''}) async {
    if (amount <= 0) throw AppError('Qarz summasini kiriting.');
    await _run((tx) => _debt(tx, partyId, amount, due, note, null, DateTime.now()));
  }

  /// To‘lov eng eski ochiq qarzdan boshlab taqsimlanadi. Mijoz to‘lasa — pul kirimi, biz to‘lasak — pul chiqimi.
  Future<void> pay(String partyId, int amount, {String note = '', String? opId}) async {
    if (amount <= 0) throw AppError('To‘lov summasini kiriting.');
    final op = opId ?? newId();
    final now = DateTime.now();
    await _run((tx) async {
      if (await _seen(tx, 'payments', '$op:0')) return;
      final pr = await tx.query('parties', where: 'id = ?', whereArgs: [partyId], limit: 1);
      if (pr.isEmpty) throw AppError('Mijoz topilmadi.');
      final isCustomer = pr.first['type'] == PartyType.customer.name;
      final rows = await tx.rawQuery(
          'SELECT d.id AS id, d.amount - COALESCE((SELECT SUM(amount) FROM payments WHERE debt_id = d.id), 0) AS rem '
          'FROM debts d WHERE d.party_id = ? ORDER BY d.ts, d.id', [partyId]);
      final totalRem = rows.fold<int>(0, (s, r) => s + max((r['rem'] as num).toInt(), 0));
      if (amount > totalRem) throw AppError('To‘lov qoldiq qarzdan oshib ketdi (qoldiq: ${uzs(totalRem)}).');
      var left = amount, i = 0;
      for (final r in rows) {
        final rem = (r['rem'] as num).toInt();
        if (rem <= 0) continue;
        if (left <= 0) break;
        final part = min(rem, left);
        await tx.insert('payments', {
          'id': newId(), 'op_id': '$op:$i', 'debt_id': r['id'], 'party_id': partyId,
          'ts': now.millisecondsSinceEpoch, 'amount': part, 'note': note,
        });
        left -= part;
        i++;
      }
      await _fin(tx, '$op:cash', isCustomer ? FinanceKind.debtCollected : FinanceKind.debtPaid, amount,
          pr.first['name'] as String, note, now);
    });
  }

  // ---------- sozlamalar / zaxira ----------
  Future<void> setTheme(ThemeMode m) async {
    await db.insert('settings', {'key': 'theme', 'value': m == ThemeMode.light ? 'light' : m == ThemeMode.dark ? 'dark' : 'system'},
        conflictAlgorithm: ConflictAlgorithm.replace);
    await reload();
  }

  Future<Uint8List> backupBytes() async {
    try {
      await db.rawQuery('PRAGMA wal_checkpoint(FULL)');
    } catch (_) {}
    return File(db.path).readAsBytes();
  }
}
