import 'dart:typed_data';

enum MovementKind { opening, purchase, sale, saleReturn, writeOff, adjustment }

extension MovementKindX on MovementKind {
  String get title => switch (this) {
        MovementKind.opening => 'Boshlang‘ich qoldiq',
        MovementKind.purchase => 'Kirim (xarid)',
        MovementKind.sale => 'Sotuv',
        MovementKind.saleReturn => 'Qaytarish',
        MovementKind.writeOff => 'Hisobdan chiqarish',
        MovementKind.adjustment => 'Inventarizatsiya',
      };
}

enum FinanceKind { saleIncome, otherIncome, debtCollected, purchaseExpense, returnRefund, otherExpense, debtPaid }

extension FinanceKindX on FinanceKind {
  String get title => switch (this) {
        FinanceKind.saleIncome => 'Sotuvdan tushum',
        FinanceKind.otherIncome => 'Boshqa kirim',
        FinanceKind.debtCollected => 'Qarz undirildi',
        FinanceKind.purchaseExpense => 'Tovar xaridi',
        FinanceKind.returnRefund => 'Qaytarilgan pul',
        FinanceKind.otherExpense => 'Boshqa xarajat',
        FinanceKind.debtPaid => 'Qarz to‘landi',
      };
  bool get isIncome =>
      this == FinanceKind.saleIncome || this == FinanceKind.otherIncome || this == FinanceKind.debtCollected;
  bool get isManual => this == FinanceKind.otherIncome || this == FinanceKind.otherExpense;
}

enum PartyType { customer, supplier }

extension PartyTypeX on PartyType {
  String get title => this == PartyType.customer ? 'Mijoz' : 'Yetkazib beruvchi';
}

T _enum<T extends Enum>(List<T> values, Object? name, T fallback) {
  for (final v in values) {
    if (v.name == name) return v;
  }
  return fallback;
}

class AppError implements Exception {
  final String message;
  AppError(this.message);
  @override
  String toString() => message;
}

class Product {
  final String id;
  final String name, barcode, category, unit, supplier, note;
  final int cost, price;
  final double qty, minQty;
  final Uint8List? image;
  final DateTime created;

  Product({
    required this.id,
    required this.name,
    this.barcode = '',
    this.category = '',
    this.unit = 'dona',
    this.supplier = '',
    this.note = '',
    this.cost = 0,
    this.price = 0,
    this.qty = 0,
    this.minQty = 0,
    this.image,
    DateTime? created,
  }) : created = created ?? DateTime.now();

  bool get isLow => minQty > 0 && qty <= minQty;
  int get stockCost => (qty * cost).round();

  factory Product.fromMap(Map<String, Object?> m) => Product(
        id: m['id'] as String,
        name: m['name'] as String,
        barcode: m['barcode'] as String,
        category: m['category'] as String,
        unit: m['unit'] as String,
        supplier: m['supplier'] as String,
        note: m['note'] as String,
        cost: (m['cost'] as num).toInt(),
        price: (m['price'] as num).toInt(),
        qty: (m['qty'] as num).toDouble(),
        minQty: (m['min_qty'] as num).toDouble(),
        image: m['image'] as Uint8List?,
        created: DateTime.fromMillisecondsSinceEpoch((m['created'] as num).toInt()),
      );
}

class Movement {
  final String id, opId, productName, note;
  final String? productId;
  final DateTime ts;
  final MovementKind kind;
  final double delta;
  final int unitPrice, unitCost;

  Movement({
    required this.id,
    required this.opId,
    required this.ts,
    required this.kind,
    required this.productId,
    required this.productName,
    required this.delta,
    required this.unitPrice,
    required this.unitCost,
    required this.note,
  });

  int get total => (delta.abs() * unitPrice).round();
  int get costTotal => (delta.abs() * unitCost).round();

  factory Movement.fromMap(Map<String, Object?> m) => Movement(
        id: m['id'] as String,
        opId: m['op_id'] as String,
        ts: DateTime.fromMillisecondsSinceEpoch((m['ts'] as num).toInt()),
        kind: _enum(MovementKind.values, m['kind'], MovementKind.purchase),
        productId: m['product_id'] as String?,
        productName: m['product_name'] as String,
        delta: (m['delta'] as num).toDouble(),
        unitPrice: (m['unit_price'] as num).toInt(),
        unitCost: (m['unit_cost'] as num).toInt(),
        note: m['note'] as String,
      );
}

class FinanceEntry {
  final String id, opId, title, note;
  final DateTime ts;
  final FinanceKind kind;
  final int amount;

  FinanceEntry({
    required this.id,
    required this.opId,
    required this.ts,
    required this.kind,
    required this.amount,
    required this.title,
    required this.note,
  });

  factory FinanceEntry.fromMap(Map<String, Object?> m) => FinanceEntry(
        id: m['id'] as String,
        opId: m['op_id'] as String,
        ts: DateTime.fromMillisecondsSinceEpoch((m['ts'] as num).toInt()),
        kind: _enum(FinanceKind.values, m['kind'], FinanceKind.otherExpense),
        amount: (m['amount'] as num).toInt(),
        title: m['title'] as String,
        note: m['note'] as String,
      );
}

class Party {
  final String id, name, phone, note;
  final PartyType type;

  Party({required this.id, required this.name, this.phone = '', this.note = '', required this.type});

  factory Party.fromMap(Map<String, Object?> m) => Party(
        id: m['id'] as String,
        name: m['name'] as String,
        phone: m['phone'] as String,
        note: m['note'] as String,
        type: _enum(PartyType.values, m['type'], PartyType.customer),
      );
}

class Debt {
  final String id, partyId, note;
  final String? movementId;
  final DateTime ts;
  final DateTime? due;
  final int amount, paid;

  Debt({
    required this.id,
    required this.partyId,
    required this.ts,
    required this.due,
    required this.amount,
    required this.paid,
    required this.note,
    required this.movementId,
  });

  int get remaining => amount - paid;
  bool get isClosed => remaining <= 0;
  bool get isOverdue {
    final d = due;
    if (d == null || isClosed) return false;
    final now = DateTime.now();
    return d.isBefore(DateTime(now.year, now.month, now.day));
  }

  factory Debt.fromMap(Map<String, Object?> m) => Debt(
        id: m['id'] as String,
        partyId: m['party_id'] as String,
        ts: DateTime.fromMillisecondsSinceEpoch((m['ts'] as num).toInt()),
        due: m['due'] == null ? null : DateTime.fromMillisecondsSinceEpoch((m['due'] as num).toInt()),
        amount: (m['amount'] as num).toInt(),
        paid: (m['paid'] as num).toInt(),
        note: m['note'] as String,
        movementId: m['movement_id'] as String?,
      );
}

class Payment {
  final String id, debtId, partyId, note;
  final DateTime ts;
  final int amount;

  Payment({required this.id, required this.debtId, required this.partyId, required this.ts, required this.amount, required this.note});

  factory Payment.fromMap(Map<String, Object?> m) => Payment(
        id: m['id'] as String,
        debtId: m['debt_id'] as String,
        partyId: m['party_id'] as String,
        ts: DateTime.fromMillisecondsSinceEpoch((m['ts'] as num).toInt()),
        amount: (m['amount'] as num).toInt(),
        note: m['note'] as String,
      );
}

/// Foyda (hisoblash usuli): sotuv summasi (qarzga berilgani ham) + boshqa kirim
///   − sotilgan tovar tannarxi − hisobdan chiqarilgan tovar tannarxi − boshqa xarajatlar.
/// Qaytarilgan tovar sotuv va tannarxdan ayriladi. Tovar xaridi va qarz to‘lovlari foydaga ta’sir qilmaydi.
/// `income`/`expense` — haqiqiy pul harakati.
class Summary {
  final int income, expense, profit, sales;
  Summary(this.income, this.expense, this.profit, this.sales);

  factory Summary.of(Iterable<FinanceEntry> fin, Iterable<Movement> mov) {
    var inc = 0, exp = 0, otherInc = 0, otherExp = 0;
    for (final e in fin) {
      if (e.kind.isIncome) {
        inc += e.amount;
      } else {
        exp += e.amount;
      }
      if (e.kind == FinanceKind.otherIncome) otherInc += e.amount;
      if (e.kind == FinanceKind.otherExpense) otherExp += e.amount;
    }
    var revenue = 0, cost = 0;
    for (final m in mov) {
      switch (m.kind) {
        case MovementKind.sale:
          revenue += m.total;
          cost += m.costTotal;
        case MovementKind.saleReturn:
          revenue -= m.total;
          cost -= m.costTotal;
        case MovementKind.writeOff:
          cost += m.costTotal;
        default:
          break;
      }
    }
    return Summary(inc, exp, revenue + otherInc - cost - otherExp, revenue);
  }
}
