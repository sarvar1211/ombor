import 'package:flutter/material.dart';

import 'dashboard.dart';
import 'debts.dart';
import 'finance.dart';
import 'products.dart';
import 'profile.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  static const _items = [
    (Icons.home_outlined, Icons.home, 'Bosh sahifa'),
    (Icons.inventory_2_outlined, Icons.inventory_2, 'Ombor'),
    (Icons.swap_horiz, Icons.swap_horiz, 'Kirim-Chiqim'),
    (Icons.menu_book_outlined, Icons.menu_book, 'Qarzlar'),
    (Icons.person_outline, Icons.person, 'Profil'),
  ];

  @override
  Widget build(BuildContext context) {
    final body = IndexedStack(index: _i, children: const [
      DashboardScreen(),
      ProductsScreen(),
      FinanceScreen(),
      DebtsScreen(),
      ProfileScreen(),
    ]);
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 800;
      if (wide) {
        final extended = c.maxWidth >= 1100;
        return Scaffold(
          body: Row(children: [
            NavigationRail(
              selectedIndex: _i,
              extended: extended,
              labelType: extended ? null : NavigationRailLabelType.all,
              onDestinationSelected: (v) => setState(() => _i = v),
              destinations: [
                for (final it in _items)
                  NavigationRailDestination(icon: Icon(it.$1), selectedIcon: Icon(it.$2), label: Text(it.$3)),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: body),
          ]),
        );
      }
      return Scaffold(
        body: body,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (v) => setState(() => _i = v),
          destinations: [
            for (final it in _items) NavigationDestination(icon: Icon(it.$1), selectedIcon: Icon(it.$2), label: it.$3),
          ],
        ),
      );
    });
  }
}
