import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../repo.dart';
import '../util.dart';
import 'widgets.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _export(BuildContext context, String name, Future<List<int>?> Function() make) async {
    try {
      final bytes = await make();
      if (bytes == null) return;
      final ok = await saveFileBytes(name, Uint8List.fromList(bytes));
      if (context.mounted && ok) showMsg(context, 'Saqlandi: $name');
    } catch (e) {
      if (context.mounted) showMsg(context, 'Xatolik: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final stamp = fmtDate(DateTime.now()).replaceAll('.', '-');
    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: ListView(padding: const EdgeInsets.all(16), children: [
            const SectionTitle('Ko‘rinish'),
            const SizedBox(height: 8),
            SegmentedButton<ThemeMode>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: ThemeMode.system, label: Text('Tizim')),
                ButtonSegment(value: ThemeMode.light, label: Text('Yorug‘')),
                ButtonSegment(value: ThemeMode.dark, label: Text('Qorong‘i')),
              ],
              selected: {r.themeMode},
              onSelectionChanged: (s) => r.setTheme(s.first),
            ),
            const SizedBox(height: 24),
            const SectionTitle('Hisobotlarni eksport qilish (CSV — Excel ochadi)'),
            const SizedBox(height: 8),
            _tile(context, 'Mahsulotlar ro‘yxati', () => _export(context, 'mahsulotlar-$stamp.csv', () async => csvBytes(
                ['Nomi', 'Shtrix-kod', 'Kategoriya', 'Kelish narxi', 'Sotish narxi', 'Miqdor', 'Birlik', 'Min. qoldiq', 'Yetkazib beruvchi', 'Izoh', 'Qoldiq tannarxi'],
                [for (final p in r.products) [p.name, p.barcode, p.category, '${p.cost}', '${p.price}', csvQty(p.qty), p.unit, csvQty(p.minQty), p.supplier, p.note, '${p.stockCost}']]))),
            _tile(context, 'Tovar harakati', () => _export(context, 'tovar-harakati-$stamp.csv', () async => csvBytes(
                ['Sana', 'Amal', 'Mahsulot', 'Miqdor (+/-)', 'Narx', 'Tannarx', 'Jami', 'Izoh'],
                [for (final m in r.movements) [fmtDateTime(m.ts), m.kind.title, m.productName, csvQty(m.delta), '${m.unitPrice}', '${m.unitCost}', '${m.total}', m.note]]))),
            _tile(context, 'Pul operatsiyalari', () => _export(context, 'pul-operatsiyalari-$stamp.csv', () async => csvBytes(
                ['Sana', 'Tur', 'Yo‘nalish', 'Nomi', 'Summa', 'Izoh'],
                [for (final e in r.finance) [fmtDateTime(e.ts), e.kind.title, e.kind.isIncome ? 'Kirim' : 'Chiqim', e.title, '${e.amount}', e.note]]))),
            _tile(context, 'Qarzlar va to‘lovlar', () => _export(context, 'qarzlar-$stamp.csv', () async => csvBytes(
                ['Kim', 'Turi', 'Telefon', 'Qarz sanasi', 'Muddat', 'Qarz summasi', 'To‘langan', 'Qoldi', 'Holat', 'Izoh'],
                [
                  for (final d in r.debts)
                    if (r.partyById(d.partyId) != null)
                      [
                        r.partyById(d.partyId)!.name, r.partyById(d.partyId)!.type.title, r.partyById(d.partyId)!.phone,
                        fmtDate(d.ts), d.due == null ? '' : fmtDate(d.due!), '${d.amount}', '${d.paid}', '${d.remaining}',
                        d.isClosed ? 'Yopilgan' : d.isOverdue ? 'Muddati o‘tgan' : 'Ochiq', d.note,
                      ]
                ]))),
            const SizedBox(height: 24),
            const SectionTitle('Zaxira nusxa'),
            const SizedBox(height: 8),
            _tile(context, 'Ma’lumotlar bazasini saqlash (.db)', () => _export(context, 'omborpro-zaxira-$stamp.db', () => r.backupBytes())),
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('Zaxira faylini xavfsiz joyda (flesh, bulut) saqlang. Qurilmalar o‘rtasida avtomatik sinxronlash keyingi bosqichda.', style: TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 24),
            const SectionTitle('Ilova haqida'),
            const ListTile(title: Text('OmborPro'), subtitle: Text('Versiya 0.2 · Pul birligi: UZS (so‘m)')),
          ]),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, String title, VoidCallback onTap) =>
      ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.download), title: Text(title), onTap: onTap);
}
