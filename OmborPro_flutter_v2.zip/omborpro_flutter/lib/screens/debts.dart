import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../repo.dart';
import '../util.dart';
import 'widgets.dart';

// ======================= QARZLAR RO‘YXATI =======================

class DebtsScreen extends StatelessWidget {
  const DebtsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Qarz daftari'),
          bottom: const TabBar(tabs: [Tab(text: 'Mijozlar'), Tab(text: 'Yetkazib beruvchilar')]),
        ),
        body: const TabBarView(children: [
          _PartyList(type: PartyType.customer),
          _PartyList(type: PartyType.supplier),
        ]),
      ),
    );
  }
}

class _PartyList extends StatelessWidget {
  final PartyType type;
  const _PartyList({required this.type});

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final list = r.partiesOf(type)..sort((a, b) => r.balanceOf(b.id).compareTo(r.balanceOf(a.id)));
    final total = list.fold(0, (s, p) => s + r.balanceOf(p.id));
    final overdue = r.overdueCount(type);
    final isCustomer = type == PartyType.customer;

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showPartyDialog(context, type),
        icon: const Icon(Icons.person_add_alt_1),
        label: Text(isCustomer ? 'Yangi mijoz' : 'Yangi yetkazib beruvchi'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Expanded(child: StatCard(title: isCustomer ? 'Mijozlarning jami qarzi' : 'Bizning jami qarzimiz', value: uzs(total), icon: Icons.account_balance_wallet, color: isCustomer ? Colors.deepPurple : Colors.brown)),
            const SizedBox(width: 12),
            Expanded(child: StatCard(title: 'Muddati o‘tgan', value: '$overdue ta', icon: Icons.alarm, color: overdue > 0 ? Colors.red : Colors.grey)),
          ]),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyState(icon: Icons.menu_book_outlined, title: isCustomer ? 'Mijozlar yo‘q' : 'Yetkazib beruvchilar yo‘q', hint: 'Pastdagi tugma orqali qo‘shing.')
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final p = list[i];
                    final bal = r.balanceOf(p.id);
                    final late = r.debtsOf(p.id).any((d) => d.isOverdue);
                    return AppCard(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PartyDetailScreen(partyId: p.id))),
                      child: Row(children: [
                        CircleAvatar(child: Text(p.name.substring(0, 1).toUpperCase())),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                            if (p.phone.isNotEmpty) Text(p.phone, style: Theme.of(context).textTheme.bodySmall),
                          ]),
                        ),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(bal > 0 ? uzs(bal) : 'Qarz yo‘q', style: TextStyle(fontWeight: FontWeight.w700, color: bal > 0 ? (late ? Colors.red : null) : Colors.green)),
                          if (late) const Text('Muddati o‘tgan', style: TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.w600)),
                        ]),
                      ]),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

// ======================= MIJOZ / YETKAZIB BERUVCHI DIALOGI =======================

Future<Party?> showPartyDialog(BuildContext context, PartyType type, {Party? existing}) {
  return showDialog<Party>(context: context, builder: (_) => _PartyDialog(type: type, existing: existing));
}

class _PartyDialog extends StatefulWidget {
  final PartyType type;
  final Party? existing;
  const _PartyDialog({required this.type, this.existing});
  @override
  State<_PartyDialog> createState() => _PartyDialogState();
}

class _PartyDialogState extends State<_PartyDialog> {
  late final _name = TextEditingController(text: widget.existing?.name ?? '');
  late final _phone = TextEditingController(text: widget.existing?.phone ?? '');
  late final _note = TextEditingController(text: widget.existing?.note ?? '');
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final repo = context.read<Repo>();
    try {
      Party result;
      final e = widget.existing;
      if (e == null) {
        result = await repo.addParty(_name.text, _phone.text, widget.type, note: _note.text);
      } else {
        result = Party(id: e.id, name: _name.text, phone: _phone.text, note: _note.text, type: e.type);
        await repo.updateParty(result);
      }
      if (mounted) Navigator.pop(context, result);
    } on AppError catch (e) {
      setState(() => _error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.existing == null ? 'Yangi: ${widget.type.title.toLowerCase()}' : 'Tahrirlash'),
        content: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _name, autofocus: true, decoration: dec('Ism-familiya')),
            const SizedBox(height: 12),
            TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: dec('Telefon raqami', hint: '+998 90 123 45 67')),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: dec('Izoh')),
            if (_error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_error!, style: const TextStyle(color: Colors.red))),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor')),
          FilledButton(onPressed: _save, child: const Text('Saqlash')),
        ],
      );
}

// ======================= BATAFSIL =======================

class PartyDetailScreen extends StatelessWidget {
  final String partyId;
  const PartyDetailScreen({super.key, required this.partyId});

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final party = r.partyById(partyId);
    if (party == null) return Scaffold(appBar: AppBar(), body: const EmptyState(icon: Icons.person_off, title: 'Topilmadi'));
    final debts = r.debtsOf(partyId).reversed.toList();
    final bal = r.balanceOf(partyId);
    final isCustomer = party.type == PartyType.customer;

    return Scaffold(
      appBar: AppBar(title: Text(party.name), actions: [
        PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'edit') {
              showPartyDialog(context, party.type, existing: party);
            } else if (v == 'delete') {
              if (await confirmDialog(context, 'O‘chirilsinmi?', party.name)) {
                try {
                  await r.deleteParty(party.id);
                  if (context.mounted) Navigator.pop(context);
                } on AppError catch (e) {
                  if (context.mounted) showMsg(context, e.message);
                }
              }
            }
          },
          itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Tahrirlash')), PopupMenuItem(value: 'delete', child: Text('O‘chirish'))],
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(party.type.title, style: Theme.of(context).textTheme.bodySmall),
            if (party.phone.isNotEmpty) Text(party.phone, style: Theme.of(context).textTheme.titleMedium),
            if (party.note.isNotEmpty) Text(party.note),
            const SizedBox(height: 10),
            Text(isCustomer ? 'Qolgan qarz (bizga to‘lashi kerak)' : 'Qolgan qarz (biz to‘lashimiz kerak)', style: Theme.of(context).textTheme.bodySmall),
            Text(uzs(bal), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: bal > 0 ? Colors.deepOrange : Colors.green)),
          ]),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(
            onPressed: bal > 0 ? () => showDialog(context: context, builder: (_) => PayDialog(party: party)) : null,
            icon: const Icon(Icons.payments),
            label: const Text('To‘lov qayd etish'),
          ),
          FilledButton.tonalIcon(
            onPressed: () => showDialog(context: context, builder: (_) => DebtDialog(party: party)),
            icon: const Icon(Icons.add),
            label: const Text('Qarz yozish'),
          ),
          if (isCustomer)
            FilledButton.tonalIcon(
              onPressed: bal > 0 ? () => _remind(context, r, party) : null,
              icon: const Icon(Icons.send),
              label: const Text('Eslatma yuborish'),
            ),
          OutlinedButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: reportText(r, party)));
              if (context.mounted) showMsg(context, 'Hisobot nusxalandi');
            },
            icon: const Icon(Icons.copy),
            label: const Text('Hisobotni nusxalash'),
          ),
        ]),
        const SizedBox(height: 16),
        const SectionTitle('Qarzlar va to‘lovlar tarixi'),
        const SizedBox(height: 8),
        if (debts.isEmpty) const Text('Hali qarz yozilmagan'),
        for (final d in debts) _DebtCard(debt: d),
      ]),
    );
  }

  Future<void> _remind(BuildContext context, Repo r, Party party) async {
    final msg = reminderText(r, party);
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.chat), title: const Text('WhatsApp'), onTap: () => Navigator.pop(c, 'wa')),
          ListTile(leading: const Icon(Icons.sms), title: const Text('SMS'), onTap: () => Navigator.pop(c, 'sms')),
          ListTile(leading: const Icon(Icons.copy), title: const Text('Matnni nusxalash'), onTap: () => Navigator.pop(c, 'copy')),
        ]),
      ),
    );
    if (choice == null) return;
    var ok = false;
    final digits = phoneDigits(party.phone);
    if (choice == 'wa' && digits.isNotEmpty) {
      ok = await launchUrl(Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent(msg)}'), mode: LaunchMode.externalApplication);
    } else if (choice == 'sms' && party.phone.isNotEmpty) {
      ok = await launchUrl(Uri(scheme: 'sms', path: party.phone, queryParameters: {'body': msg}));
    }
    if (!ok) {
      await Clipboard.setData(ClipboardData(text: msg));
      if (context.mounted) showMsg(context, choice == 'copy' ? 'Matn nusxalandi' : 'Ochib bo‘lmadi — matn nusxalandi, o‘zingiz yuboring');
    }
  }
}

String reminderText(Repo r, Party p) {
  final bal = r.balanceOf(p.id);
  final late = r.debtsOf(p.id).where((d) => d.isOverdue).toList();
  final b = StringBuffer('Assalomu alaykum, ${p.name}! ');
  b.write('Sizning qolgan qarzingiz: ${uzs(bal)}.');
  if (late.isNotEmpty) b.write(' Shundan muddati o‘tgani: ${uzs(late.fold(0, (s, d) => s + d.remaining))}.');
  b.write(' Iltimos, to‘lovni amalga oshiring. Rahmat!');
  return b.toString();
}

String reportText(Repo r, Party p) {
  final b = StringBuffer()..writeln('${p.type.title}: ${p.name}${p.phone.isEmpty ? '' : ' (${p.phone})'}');
  b.writeln('Hisobot sanasi: ${fmtDate(DateTime.now())}');
  b.writeln('Qolgan qarz: ${uzs(r.balanceOf(p.id))}');
  b.writeln('');
  for (final d in r.debtsOf(p.id)) {
    b.writeln('${fmtDate(d.ts)} — ${d.note.isEmpty ? 'Qarz' : d.note}: ${uzs(d.amount)}'
        '${d.due == null ? '' : ', muddat ${fmtDate(d.due!)}'} (${d.isClosed ? 'Yopilgan' : 'qoldi ${uzs(d.remaining)}'})');
    for (final pay in r.paymentsOf(d.id).reversed) {
      b.writeln('   ${fmtDate(pay.ts)} to‘lov: ${uzs(pay.amount)}');
    }
  }
  return b.toString();
}

class _DebtCard extends StatelessWidget {
  final Debt debt;
  const _DebtCard({required this.debt});

  @override
  Widget build(BuildContext context) {
    final r = context.read<Repo>();
    final pays = r.paymentsOf(debt.id).reversed.toList();
    final (label, color) = debt.isClosed
        ? ('Yopilgan', Colors.green)
        : debt.isOverdue
            ? ('Muddati o‘tgan', Colors.red)
            : ('Ochiq', Colors.orange);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(debt.note.isEmpty ? 'Qarz' : debt.note, style: const TextStyle(fontWeight: FontWeight.w600))),
            Chip(label: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12)), backgroundColor: color.withOpacity(0.12), side: BorderSide.none, visualDensity: VisualDensity.compact),
          ]),
          Text('${fmtDate(debt.ts)}${debt.due == null ? '' : ' · muddat: ${fmtDate(debt.due!)}'}', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Qarz: ${uzs(debt.amount)}'),
            Text('To‘langan: ${uzs(debt.paid)}'),
            Text('Qoldi: ${uzs(debt.remaining)}', style: const TextStyle(fontWeight: FontWeight.w700)),
          ]),
          for (final p in pays)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('↳ ${fmtDateTime(p.ts)} — to‘lov ${uzs(p.amount)}${p.note.isEmpty ? '' : ' (${p.note})'}', style: Theme.of(context).textTheme.bodySmall),
            ),
        ]),
      ),
    );
  }
}

// ======================= QARZ YOZISH / TO‘LOV =======================

class DebtDialog extends StatefulWidget {
  final Party party;
  const DebtDialog({super.key, required this.party});
  @override
  State<DebtDialog> createState() => _DebtDialogState();
}

class _DebtDialogState extends State<DebtDialog> {
  final _amount = TextEditingController(), _note = TextEditingController();
  DateTime? _due;
  String? _error;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final a = parseMoney(_amount.text);
    if (a == null || a <= 0) return setState(() => _error = 'Summani to‘g‘ri kiriting.');
    try {
      await context.read<Repo>().addDebt(widget.party.id, a, due: _due, note: _note.text);
      if (mounted) Navigator.pop(context);
    } on AppError catch (e) {
      setState(() => _error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Qarz yozish'),
        content: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _amount, autofocus: true, keyboardType: TextInputType.number, decoration: dec('Qarz summasi', suffix: 'so‘m')),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: dec('Izoh')),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                final d = await pickDate(context, initial: _due);
                if (d != null) setState(() => _due = d);
              },
              icon: const Icon(Icons.event),
              label: Text(_due == null ? 'To‘lash muddati (ixtiyoriy)' : 'Muddat: ${fmtDate(_due!)}'),
            ),
            const SizedBox(height: 6),
            const Text('Eslatma: bu yerda tovar ombordan chiqmaydi. Tovar sotib qarz yozish uchun Ombor → mahsulot → Sotuv dan foydalaning.', style: TextStyle(fontSize: 11)),
            if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: Colors.red))),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor')),
          FilledButton(onPressed: _save, child: const Text('Saqlash')),
        ],
      );
}

class PayDialog extends StatefulWidget {
  final Party party;
  const PayDialog({super.key, required this.party});
  @override
  State<PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<PayDialog> {
  final _amount = TextEditingController(), _note = TextEditingController();
  final _op = newId(); // takroriy bosishdan himoya
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final a = parseMoney(_amount.text);
    if (a == null || a <= 0) return setState(() => _error = 'Summani to‘g‘ri kiriting.');
    setState(() => _busy = true);
    try {
      await context.read<Repo>().pay(widget.party.id, a, note: _note.text, opId: _op);
      if (mounted) Navigator.pop(context);
    } on AppError catch (e) {
      setState(() {
        _busy = false;
        _error = e.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bal = context.watch<Repo>().balanceOf(widget.party.id);
    return AlertDialog(
      title: const Text('To‘lovni qayd etish'),
      content: SizedBox(
        width: 400,
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Qolgan qarz: ${uzs(bal)}'),
          const SizedBox(height: 12),
          TextField(controller: _amount, autofocus: true, keyboardType: TextInputType.number, decoration: dec('To‘lov summasi', suffix: 'so‘m')),
          Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => setState(() => _amount.text = bal.toString()), child: const Text('To‘liq qoldiq'))),
          TextField(controller: _note, decoration: dec('Izoh')),
          if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: Colors.red))),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Saqlash')),
      ],
    );
  }
}
