import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../repo.dart';
import '../util.dart';
import 'widgets.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _days = 7;

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final now = DateTime.now();
    final tf = r.finance.where((e) => isSameDay(e.ts, now)).toList();
    final tm = r.movements.where((m) => isSameDay(m.ts, now)).toList();
    final today = Summary.of(tf, tm);
    final total = Summary.of(r.finance, r.movements);
    final low = r.products.where((p) => p.isLow).toList()..sort((a, b) => a.qty.compareTo(b.qty));
    final units = r.products.fold<double>(0, (s, p) => s + p.qty);
    final overdue = r.overdueCount(PartyType.customer) + r.overdueCount(PartyType.supplier);

    final cards = <Widget>[
      StatCard(title: 'Mahsulot turlari / jami birlik', value: '${r.products.length} / ${qtyText(units)}', icon: Icons.inventory_2),
      StatCard(title: 'Ombor tannarxi', value: uzs(r.products.fold(0, (s, p) => s + p.stockCost)), icon: Icons.payments, color: Colors.indigo),
      StatCard(title: 'Bugungi kirim (pul)', value: uzs(today.income), icon: Icons.south_west, color: Colors.green),
      StatCard(title: 'Bugungi chiqim (pul)', value: uzs(today.expense), icon: Icons.north_east, color: Colors.orange),
      StatCard(title: 'Bugungi sotuv', value: uzs(today.sales), icon: Icons.shopping_cart, color: Colors.teal),
      StatCard(title: 'Bugungi foyda', value: uzs(today.profit), icon: Icons.trending_up, color: today.profit >= 0 ? Colors.green : Colors.red),
      StatCard(title: 'Jami foyda', value: uzs(total.profit), icon: Icons.star, color: total.profit >= 0 ? Colors.green : Colors.red),
      StatCard(title: 'Mijozlarning qarzi', value: uzs(r.customersOwe), icon: Icons.person_search, color: Colors.deepPurple),
      StatCard(title: 'Bizning qarzimiz', value: uzs(r.weOwe), icon: Icons.account_balance_wallet, color: Colors.brown),
      StatCard(title: 'Muddati o‘tgan qarzlar', value: '$overdue ta', icon: Icons.alarm, color: overdue > 0 ? Colors.red : Colors.grey),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('OmborPro')),
      body: LayoutBuilder(builder: (context, c) {
        final cols = c.maxWidth >= 1000 ? 5 : c.maxWidth >= 700 ? 4 : c.maxWidth >= 480 ? 3 : 2;
        const gap = 12.0;
        final w = (c.maxWidth - 32 - gap * (cols - 1)) / cols;
        return ListView(padding: const EdgeInsets.all(16), children: [
          Wrap(spacing: gap, runSpacing: gap, children: [for (final x in cards) SizedBox(width: w, child: x)]),
          const SizedBox(height: 16),
          if (low.isNotEmpty) ...[
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.orange),
                  SizedBox(width: 8),
                  SectionTitle('Kam qolgan mahsulotlar'),
                ]),
                const SizedBox(height: 8),
                for (final p in low.take(6))
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(children: [
                      Expanded(child: Text(p.name, overflow: TextOverflow.ellipsis)),
                      Text('${qtyText(p.qty)} ${p.unit}', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                if (low.length > 6) Text('va yana ${low.length - 6} ta…', style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
            const SizedBox(height: 16),
          ],
          AppCard(child: _chart(r)),
          const SizedBox(height: 16),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionTitle('Oxirgi operatsiyalar'),
              const SizedBox(height: 8),
              if (r.movements.isEmpty) const Text('Hali operatsiyalar yo‘q'),
              for (final m in r.movements.take(8)) MovementTile(m),
            ]),
          ),
        ]);
      }),
    );
  }

  Widget _chart(Repo r) {
    final start = startOfDay(DateTime.now());
    final days = [for (var i = _days - 1; i >= 0; i--) start.subtract(Duration(days: i))];
    final inc = <double>[], exp = <double>[];
    for (final d in days) {
      var a = 0, b = 0;
      for (final e in r.finance) {
        if (!isSameDay(e.ts, d)) continue;
        if (e.kind.isIncome) {
          a += e.amount;
        } else {
          b += e.amount;
        }
      }
      inc.add(a.toDouble());
      exp.add(b.toDouble());
    }
    final empty = r.finance.isEmpty;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Expanded(child: SectionTitle('Kirim va chiqim')),
        SegmentedButton<int>(
          showSelectedIcon: false,
          segments: const [ButtonSegment(value: 7, label: Text('7 kun')), ButtonSegment(value: 30, label: Text('30 kun'))],
          selected: {_days},
          onSelectionChanged: (s) => setState(() => _days = s.first),
        ),
      ]),
      const SizedBox(height: 12),
      SizedBox(
        height: 200,
        child: empty
            ? const Center(child: Text('Hali operatsiyalar yo‘q'))
            : BarChart(BarChartData(
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 24,
                      getTitlesWidget: (v, meta) {
                        final i = v.toInt();
                        if (i < 0 || i >= days.length) return const SizedBox.shrink();
                        if (_days > 7 && i % 5 != 0) return const SizedBox.shrink();
                        return Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text('${days[i].day}.${days[i].month}', style: const TextStyle(fontSize: 10)),
                        );
                      },
                    ),
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < days.length; i++)
                    BarChartGroupData(x: i, barsSpace: 2, barRods: [
                      BarChartRodData(toY: inc[i], color: Colors.green, width: _days > 7 ? 4 : 10, borderRadius: BorderRadius.circular(2)),
                      BarChartRodData(toY: exp[i], color: Colors.orange, width: _days > 7 ? 4 : 10, borderRadius: BorderRadius.circular(2)),
                    ]),
                ],
              )),
      ),
      const SizedBox(height: 6),
      const Row(children: [
        Icon(Icons.circle, size: 10, color: Colors.green), SizedBox(width: 4), Text('Kirim'),
        SizedBox(width: 16),
        Icon(Icons.circle, size: 10, color: Colors.orange), SizedBox(width: 4), Text('Chiqim'),
      ]),
    ]);
  }
}

class MovementTile extends StatelessWidget {
  final Movement m;
  const MovementTile(this.m, {super.key});

  @override
  Widget build(BuildContext context) {
    final inbound = m.delta >= 0;
    final color = inbound ? Colors.green : Colors.red;
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(radius: 16, backgroundColor: color.withOpacity(0.12), child: Icon(inbound ? Icons.add : Icons.remove, size: 18, color: color)),
      title: Text(m.productName, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${m.kind.title} · ${fmtDateTime(m.ts)}'),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(signedQty(m.delta), style: TextStyle(color: color, fontWeight: FontWeight.w700)),
        if (m.total > 0) Text(uzs(m.total), style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}
