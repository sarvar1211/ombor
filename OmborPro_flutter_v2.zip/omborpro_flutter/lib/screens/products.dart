import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../repo.dart';
import '../util.dart';
import 'dashboard.dart' show MovementTile;
import 'debts.dart' show showPartyDialog;
import 'widgets.dart';

// ======================= RO‘YXAT =======================

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _search = TextEditingController();
  String? _category;
  bool _lowOnly = false;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final q = _search.text.trim().toLowerCase();
    final cats = r.products.map((p) => p.category).where((c) => c.isNotEmpty).toSet().toList()..sort();
    final list = r.products.where((p) {
      if (_category != null && p.category != _category) return false;
      if (_lowOnly && !p.isLow) return false;
      if (q.isEmpty) return true;
      return p.name.toLowerCase().contains(q) || p.barcode.toLowerCase().contains(q) || p.supplier.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Ombor')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductFormScreen())),
        icon: const Icon(Icons.add),
        label: const Text('Mahsulot'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Nom, shtrix-kod yoki yetkazib beruvchi',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _search.text.isEmpty
                  ? null
                  : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(_search.clear)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              isDense: true,
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            _chip('Hammasi', _category == null && !_lowOnly, () => setState(() {
                  _category = null;
                  _lowOnly = false;
                })),
            _chip('Kam qolgan', _lowOnly, () => setState(() => _lowOnly = !_lowOnly)),
            for (final c in cats) _chip(c, _category == c, () => setState(() => _category = _category == c ? null : c)),
          ]),
        ),
        Expanded(
          child: r.products.isEmpty
              ? const EmptyState(icon: Icons.inventory_2_outlined, title: 'Ombor bo‘sh', hint: 'Birinchi mahsulotni qo‘shing.')
              : list.isEmpty
                  ? const EmptyState(icon: Icons.search_off, title: 'Hech narsa topilmadi')
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) => _row(context, list[i]),
                    ),
        ),
      ]),
    );
  }

  Widget _chip(String t, bool sel, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(right: 8, top: 6, bottom: 6),
        child: ChoiceChip(label: Text(t), selected: sel, onSelected: (_) => f()),
      );

  Widget _row(BuildContext context, Product p) => AppCard(
        padding: const EdgeInsets.all(10),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(productId: p.id))),
        child: Row(children: [
          ProductThumb(data: p.image),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text('${uzs(p.price)}${p.category.isEmpty ? '' : ' · ${p.category}'}', style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${qtyText(p.qty)} ${p.unit}',
                style: TextStyle(fontWeight: FontWeight.w700, color: p.isLow ? Colors.red : null)),
            if (p.isLow) const Text('Kam qoldi', style: TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        ]),
      );
}

// ======================= BATAFSIL =======================

class ProductDetailScreen extends StatelessWidget {
  final String productId;
  const ProductDetailScreen({super.key, required this.productId});

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    final p = r.products.where((x) => x.id == productId).firstOrNull;
    if (p == null) return Scaffold(appBar: AppBar(), body: const EmptyState(icon: Icons.inventory_2_outlined, title: 'Mahsulot topilmadi'));
    final hist = r.movements.where((m) => m.productId == p.id).toList();

    Widget kv(String k, String v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: Text(k, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.outline))),
            Flexible(child: Text(v, textAlign: TextAlign.right)),
          ]),
        );

    Widget act(MovementKind k, IconData i) => FilledButton.tonalIcon(
          onPressed: () => showDialog(context: context, builder: (_) => StockActionDialog(product: p, kind: k)),
          icon: Icon(i, size: 18),
          label: Text(k.title),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('Mahsulot'), actions: [
        PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'edit') {
              Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: p)));
            } else if (v == 'delete') {
              if (await confirmDialog(context, 'Mahsulot o‘chirilsinmi?', 'Operatsiyalar tarixi saqlanib qoladi.')) {
                await r.deleteProduct(p.id);
                if (context.mounted) Navigator.pop(context);
              }
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'edit', child: Text('Tahrirlash')),
            PopupMenuItem(value: 'delete', child: Text('O‘chirish')),
          ],
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          child: Row(children: [
            ProductThumb(data: p.image, size: 72),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                if (p.category.isNotEmpty) Text(p.category),
                Text('${qtyText(p.qty)} ${p.unit}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(color: p.isLow ? Colors.red : Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          act(MovementKind.purchase, Icons.add_box_outlined),
          act(MovementKind.sale, Icons.shopping_cart_outlined),
          act(MovementKind.saleReturn, Icons.undo),
          act(MovementKind.writeOff, Icons.delete_outline),
          act(MovementKind.adjustment, Icons.fact_check_outlined),
        ]),
        const SizedBox(height: 12),
        AppCard(
          child: Column(children: [
            kv('Kelish narxi (o‘rtacha)', uzs(p.cost)),
            kv('Sotish narxi', uzs(p.price)),
            kv('Qoldiq tannarxi', uzs(p.stockCost)),
            kv('Minimal qoldiq', '${qtyText(p.minQty)} ${p.unit}'),
            if (p.barcode.isNotEmpty) kv('Shtrix-kod', p.barcode),
            if (p.supplier.isNotEmpty) kv('Yetkazib beruvchi', p.supplier),
            if (p.note.isNotEmpty) kv('Izoh', p.note),
          ]),
        ),
        const SizedBox(height: 12),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionTitle('Kirim-chiqim tarixi'),
            const SizedBox(height: 6),
            if (hist.isEmpty) const Text('Hali operatsiyalar yo‘q'),
            for (final m in hist) MovementTile(m),
          ]),
        ),
      ]),
    );
  }
}

// ======================= AMAL OYNASI =======================

class StockActionDialog extends StatefulWidget {
  final Product product;
  final MovementKind kind;
  const StockActionDialog({super.key, required this.product, required this.kind});
  @override
  State<StockActionDialog> createState() => _StockActionDialogState();
}

class _StockActionDialogState extends State<StockActionDialog> {
  final _qty = TextEditingController();
  final _price = TextEditingController();
  final _paid = TextEditingController();
  final _note = TextEditingController();
  final _op = newId(); // takroriy bosishdan himoya
  bool _paidEdited = false, _busy = false;
  String? _partyId, _error;
  DateTime? _due;

  MovementKind get kind => widget.kind;
  Product get p => widget.product;
  bool get _hasPrice => kind == MovementKind.purchase || kind == MovementKind.sale || kind == MovementKind.saleReturn;
  bool get _hasPaid => kind == MovementKind.purchase || kind == MovementKind.sale;

  int get _total {
    final q = parseNum(_qty.text), pr = parseMoney(_price.text);
    return (q == null || pr == null) ? 0 : (q * pr).round();
  }

  int get _paidAmt => _paidEdited ? (parseMoney(_paid.text) ?? 0) : _total;

  @override
  void initState() {
    super.initState();
    switch (kind) {
      case MovementKind.purchase:
      case MovementKind.writeOff:
        _price.text = p.cost.toString();
      case MovementKind.sale:
      case MovementKind.saleReturn:
        _price.text = p.price.toString();
      case MovementKind.adjustment:
        _qty.text = csvQty(p.qty);
      case MovementKind.opening:
        break;
    }
  }

  @override
  void dispose() {
    for (final c in [_qty, _price, _paid, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final q = parseNum(_qty.text);
    if (q == null) return setState(() => _error = 'Miqdorni kiriting.');
    final price = parseMoney(_price.text) ?? 0;
    final total = (q * price).round();
    final paid = _paidAmt;
    if (_hasPaid && paid > total) return setState(() => _error = 'To‘langan summa jami summadan oshmasligi kerak.');
    final repo = context.read<Repo>();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      switch (kind) {
        case MovementKind.purchase:
          await repo.receive(p, q, price, note: _note.text, opId: _op, paid: paid, partyId: _partyId, due: _due);
        case MovementKind.sale:
          await repo.sell(p, q, price, note: _note.text, opId: _op, paid: paid, partyId: _partyId, due: _due);
        case MovementKind.saleReturn:
          await repo.returnItem(p, q, price, note: _note.text, opId: _op);
        case MovementKind.writeOff:
          await repo.writeOff(p, q, note: _note.text, opId: _op);
        case MovementKind.adjustment:
          await repo.adjust(p, q, note: _note.text, opId: _op);
        case MovementKind.opening:
          break;
      }
      if (mounted) Navigator.pop(context);
    } on AppError catch (e) {
      if (mounted) setState(() {
        _busy = false;
        _error = e.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<Repo>();
    final type = kind == MovementKind.sale ? PartyType.customer : PartyType.supplier;
    final rest = _hasPaid ? _total - _paidAmt : 0;
    return AlertDialog(
      title: Text('${kind.title}: ${p.name}', maxLines: 2, overflow: TextOverflow.ellipsis),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Hozirgi qoldiq: ${qtyText(p.qty)} ${p.unit}'),
            const SizedBox(height: 12),
            TextField(
              controller: _qty,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => setState(() {
                if (!_paidEdited) _paid.text = '';
              }),
              decoration: dec(kind == MovementKind.adjustment ? 'Haqiqiy qoldiq' : 'Miqdor', suffix: p.unit),
            ),
            if (_hasPrice) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _price,
                keyboardType: TextInputType.number,
                onChanged: (_) => setState(() {}),
                decoration: dec(kind == MovementKind.purchase ? 'Kelish narxi' : 'Narx', suffix: 'so‘m'),
              ),
              const SizedBox(height: 8),
              Text('Jami: ${uzs(_total)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            ],
            if (_hasPaid) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _paid,
                keyboardType: TextInputType.number,
                onChanged: (v) => setState(() => _paidEdited = v.trim().isNotEmpty),
                decoration: dec('To‘langan summa', suffix: 'so‘m', hint: _total.toString()),
              ),
              if (rest > 0) ...[
                const SizedBox(height: 8),
                Text('Qarz bo‘lib yoziladi: ${uzs(rest)}', style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: repo.partiesOf(type).any((x) => x.id == _partyId) ? _partyId : null,
                      isExpanded: true,
                      decoration: dec(type.title),
                      items: [for (final x in repo.partiesOf(type)) DropdownMenuItem(value: x.id, child: Text(x.name, overflow: TextOverflow.ellipsis))],
                      onChanged: (v) => setState(() => _partyId = v),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Yangi',
                    icon: const Icon(Icons.person_add_alt),
                    onPressed: () async {
                      final np = await showPartyDialog(context, type);
                      if (np != null) setState(() => _partyId = np.id);
                    },
                  ),
                ]),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () async {
                    final d = await pickDate(context, initial: _due);
                    if (d != null) setState(() => _due = d);
                  },
                  icon: const Icon(Icons.event),
                  label: Text(_due == null ? 'To‘lash muddati (ixtiyoriy)' : 'Muddat: ${fmtDate(_due!)}'),
                ),
              ],
            ],
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: dec('Izoh')),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('Bekor')),
        FilledButton(onPressed: _busy ? null : _save, child: const Text('Saqlash')),
      ],
    );
  }
}

// ======================= FORMA =======================

class ProductFormScreen extends StatefulWidget {
  final Product? product;
  const ProductFormScreen({super.key, this.product});
  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  static const _units = ['dona', 'kg', 'g', 'litr', 'metr', 'qop', 'quti', 'paket'];
  late final TextEditingController _name, _barcode, _category, _supplier, _note, _cost, _price, _opening, _minQty;
  late String _unit;
  Uint8List? _image;
  String? _error;
  bool _busy = false;
  final _op = newId();

  Product? get _p => widget.product;

  @override
  void initState() {
    super.initState();
    final p = _p;
    _name = TextEditingController(text: p?.name ?? '');
    _barcode = TextEditingController(text: p?.barcode ?? '');
    _category = TextEditingController(text: p?.category ?? '');
    _supplier = TextEditingController(text: p?.supplier ?? '');
    _note = TextEditingController(text: p?.note ?? '');
    _cost = TextEditingController(text: p == null ? '' : p.cost.toString());
    _price = TextEditingController(text: p == null ? '' : p.price.toString());
    _opening = TextEditingController();
    _minQty = TextEditingController(text: p == null || p.minQty == 0 ? '' : csvQty(p.minQty));
    _unit = p?.unit ?? 'dona';
    _image = p?.image;
  }

  @override
  void dispose() {
    for (final c in [_name, _barcode, _category, _supplier, _note, _cost, _price, _opening, _minQty]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickImage() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    final bytes = res?.files.firstOrNull?.bytes;
    if (bytes == null) return;
    final small = await shrinkImage(bytes);
    if (mounted) setState(() => _image = small);
  }

  Future<void> _save() async {
    final cost = _cost.text.trim().isEmpty ? 0 : parseMoney(_cost.text);
    final price = _price.text.trim().isEmpty ? 0 : parseMoney(_price.text);
    final minQ = _minQty.text.trim().isEmpty ? 0.0 : parseNum(_minQty.text);
    final open = _opening.text.trim().isEmpty ? 0.0 : parseNum(_opening.text);
    if (_name.text.trim().isEmpty) return setState(() => _error = 'Mahsulot nomini kiriting.');
    if (cost == null || price == null) return setState(() => _error = 'Narxlarni to‘g‘ri kiriting.');
    if (minQ == null || minQ < 0) return setState(() => _error = 'Minimal qoldiq noto‘g‘ri.');
    if (open == null || open < 0) return setState(() => _error = 'Boshlang‘ich qoldiq noto‘g‘ri.');

    final repo = context.read<Repo>();
    final prod = Product(
      id: _p?.id ?? newId(),
      name: _name.text,
      barcode: _barcode.text,
      category: _category.text,
      supplier: _supplier.text,
      note: _note.text,
      cost: cost,
      price: price,
      unit: _unit,
      minQty: minQ,
      image: _image,
    );
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (_p == null) {
        await repo.createProduct(prod, open, opId: _op);
      } else {
        await repo.updateProduct(prod);
      }
      if (mounted) Navigator.pop(context);
    } on AppError catch (e) {
      if (mounted) setState(() {
        _busy = false;
        _error = e.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = context.read<Repo>().products.map((p) => p.category).where((c) => c.isNotEmpty).toSet().toList()..sort();
    const gap = SizedBox(height: 12);
    return Scaffold(
      appBar: AppBar(title: Text(_p == null ? 'Yangi mahsulot' : 'Tahrirlash'), actions: [
        TextButton(onPressed: _busy ? null : _save, child: const Text('Saqlash')),
      ]),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              ProductThumb(data: _image, size: 72),
              const SizedBox(width: 12),
              OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.photo), label: Text(_image == null ? 'Rasm tanlash' : 'Almashtirish')),
              if (_image != null) IconButton(onPressed: () => setState(() => _image = null), icon: const Icon(Icons.close)),
            ]),
            gap,
            TextField(controller: _name, decoration: dec('Mahsulot nomi')),
            gap,
            TextField(controller: _barcode, decoration: dec('Shtrix-kod / kod (ixtiyoriy)')),
            gap,
            Row(children: [
              Expanded(child: TextField(controller: _category, decoration: dec('Kategoriya'))),
              if (cats.isNotEmpty)
                PopupMenuButton<String>(
                  icon: const Icon(Icons.arrow_drop_down_circle_outlined),
                  onSelected: (c) => setState(() => _category.text = c),
                  itemBuilder: (_) => [for (final c in cats) PopupMenuItem(value: c, child: Text(c))],
                ),
            ]),
            gap,
            TextField(controller: _supplier, decoration: dec('Yetkazib beruvchi')),
            gap,
            Row(children: [
              Expanded(child: TextField(controller: _cost, keyboardType: TextInputType.number, decoration: dec('Kelish narxi', suffix: 'so‘m'))),
              const SizedBox(width: 12),
              Expanded(child: TextField(controller: _price, keyboardType: TextInputType.number, decoration: dec('Sotish narxi', suffix: 'so‘m'))),
            ]),
            gap,
            DropdownButtonFormField<String>(
              value: _unit,
              decoration: dec('O‘lchov birligi'),
              items: [for (final u in _units) DropdownMenuItem(value: u, child: Text(u))],
              onChanged: (v) => setState(() => _unit = v ?? _unit),
            ),
            gap,
            Row(children: [
              if (_p == null) ...[
                Expanded(child: TextField(controller: _opening, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: dec('Boshlang‘ich qoldiq'))),
                const SizedBox(width: 12),
              ],
              Expanded(child: TextField(controller: _minQty, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: dec('Minimal qoldiq'))),
            ]),
            gap,
            TextField(controller: _note, maxLines: 2, decoration: dec('Izoh')),
            if (_error != null) ...[gap, Text(_error!, style: const TextStyle(color: Colors.red))],
            const SizedBox(height: 24),
            FilledButton(onPressed: _busy ? null : _save, child: const Padding(padding: EdgeInsets.all(12), child: Text('Saqlash'))),
          ]),
        ),
      ),
    );
  }
}
