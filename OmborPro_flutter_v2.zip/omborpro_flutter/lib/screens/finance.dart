import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../repo.dart';
import '../util.dart';
import 'dashboard.dart' show MovementTile;
import 'widgets.dart';

class FinanceScreen extends StatefulWidget {
  const FinanceScreen({super.key});
  @override
  State<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  int _filter = 0; // 0 hammasi, 1 kirim, 2 chiqim

  @override
  Widget build(BuildContext context) {
    final r = context.watch<Repo>();
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Kirim-Chiqim'),
          bottom: const TabBar(tabs: [Tab(text: 'Pul'), Tab(text: 'Tovar')]),
          actions: [
            PopupMenuButton<FinanceKind>(
              icon: const Icon(Icons.add_circle_outline),
              tooltip: 'Qo‘shish',
              onSelected: (k) => showDialog(context: context, builder: (_) => OtherEntryDialog(kind: k)),
              itemBuilder: (_) => const [
                PopupMenuItem(value: FinanceKind.otherExpense, child: Text('Boshqa xarajat')),
                PopupMenuItem(value: FinanceKind.otherIncome, child: Text('Boshqa kirim')),
              ],
            ),
          ],
        ),
        body: TabBarView(children: [_money(context, r), _goods(r)]),
      ),
    );
  }

  Widget _money(BuildContext context, Repo r) {
    final list = r.finance.where((e) => _filter == 0 || (_filter == 1) == e.kind.isIncome).toList();
    final inc = list.where((e) => e.kind.isIncome).fold(0, (s, e) => s + e.amount);
    final exp = list.where((e) => !e.kind.isIncome).fold(0, (s, e) => s + e.amount);
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Column(children: [
          SegmentedButton<int>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: 0, label: Text('Hammasi')),
              ButtonSegment(value: 1, label: Text('Kirim')),
              ButtonSegment(value: 2, label: Text('Chiqim')),
            ],
            selected: {_filter},
            onSelectionChanged: (s) => setState(() => _filter = s.first),
          ),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Kirim: ${uzs(inc)}', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w700)),
            Text('Chiqim: ${uzs(exp)}', style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.w700)),
          ]),
        ]),
      ),
      Expanded(
        child: list.isEmpty
            ? const EmptyState(icon: Icons.payments_outlined, title: 'Operatsiyalar yo‘q')
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final e = list[i];
                  final inc = e.kind.isIncome;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: (inc ? Colors.green : Colors.orange).withOpacity(0.14),
                      child: Icon(inc ? Icons.south_west : Icons.north_east, color: inc ? Colors.green : Colors.orange, size: 20),
                    ),
                    title: Text(e.title.isEmpty ? e.kind.title : e.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${e.kind.title} · ${fmtDateTime(e.ts)}${e.note.isEmpty ? '' : '\n${e.note}'}'),
                    isThreeLine: e.note.isNotEmpty,
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${inc ? '+' : '−'}${uzs(e.amount)}', style: TextStyle(fontWeight: FontWeight.w700, color: inc ? Colors.green : null)),
                      if (e.kind.isManual)
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20),
                          onPressed: () async {
                            if (await confirmDialog(context, 'Yozuv o‘chirilsinmi?', '${e.kind.title}: ${uzs(e.amount)}')) {
                              await r.deleteOther(e);
                            }
                          },
                        ),
                    ]),
                  );
                },
              ),
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Text('Sotuv, xarid va qarz to‘lovlarini o‘chirib bo‘lmaydi: ular ombor/qarz bilan bog‘langan. Xato bo‘lsa «Qaytarish» yoki «Inventarizatsiya»dan foydalaning.',
            style: TextStyle(fontSize: 11), textAlign: TextAlign.center),
      ),
    ]);
  }

  Widget _goods(Repo r) => r.movements.isEmpty
      ? const EmptyState(icon: Icons.inventory_2_outlined, title: 'Tovar harakati yo‘q')
      : ListView(padding: const EdgeInsets.all(16), children: [for (final m in r.movements) MovementTile(m)]);
}

class OtherEntryDialog extends StatefulWidget {
  final FinanceKind kind;
  const OtherEntryDialog({super.key, required this.kind});
  @override
  State<OtherEntryDialog> createState() => _OtherEntryDialogState();
}

class _OtherEntryDialogState extends State<OtherEntryDialog> {
  final _title = TextEditingController(), _amount = TextEditingController(), _note = TextEditingController();
  final _op = newId();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _title.dispose();
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final a = parseMoney(_amount.text);
    if (a == null || a <= 0) return setState(() => _error = 'Summani to‘g‘ri kiriting.');
    setState(() => _busy = true);
    try {
      await context.read<Repo>().addOther(widget.kind, a, _title.text.trim(), note: _note.text, opId: _op);
      if (mounted) Navigator.pop(context);
    } on AppError catch (e) {
      if (mounted) setState(() {
        _busy = false;
        _error = e.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.kind.title),
        content: SizedBox(
          width: 400,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: _title, autofocus: true, decoration: dec(widget.kind == FinanceKind.otherExpense ? 'Nima uchun (ijara, transport…)' : 'Manba')),
            const SizedBox(height: 12),
            TextField(controller: _amount, keyboardType: TextInputType.number, decoration: dec('Summa', suffix: 'so‘m')),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: dec('Izoh')),
            if (_error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_error!, style: const TextStyle(color: Colors.red))),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor')),
          FilledButton(onPressed: _busy ? null : _save, child: const Text('Saqlash')),
        ],
      );
}
