import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

final _rnd = Random.secure();

String newId() {
  final b = List<int>.generate(8, (_) => _rnd.nextInt(256));
  return DateTime.now().microsecondsSinceEpoch.toRadixString(36) +
      b.map((e) => e.toRadixString(16).padLeft(2, '0')).join();
}

String _group(String digits) {
  final b = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) b.write(' ');
    b.write(digits[i]);
  }
  return b.toString();
}

String money(int v) => '${v < 0 ? '−' : ''}${_group(v.abs().toString())}';
String uzs(int v) => '${money(v)} so‘m';

String qtyText(double q) {
  final sign = q < 0 ? '−' : '';
  final a = q.abs();
  if ((a - a.roundToDouble()).abs() < 1e-9) return '$sign${_group(a.round().toString())}';
  var s = a.toStringAsFixed(3);
  s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  final parts = s.split('.');
  return '$sign${_group(parts[0])}${parts.length > 1 ? ',${parts[1]}' : ''}';
}

String signedQty(double q) => q > 0 ? '+${qtyText(q)}' : qtyText(q);
String csvQty(double q) => (q - q.roundToDouble()).abs() < 1e-9 ? q.round().toString() : q.toString().replaceAll('.', ',');

double? parseNum(String s) {
  final t = s.replaceAll(RegExp(r'[\s\u00A0]'), '').replaceAll(',', '.');
  if (t.isEmpty) return null;
  return double.tryParse(t);
}

int? parseMoney(String s) {
  final d = parseNum(s);
  if (d == null || d < 0 || d >= 1e13) return null;
  return d.round();
}

String _two(int n) => n.toString().padLeft(2, '0');
String fmtDate(DateTime d) => '${_two(d.day)}.${_two(d.month)}.${d.year}';
String fmtDateTime(DateTime d) => '${fmtDate(d)} ${_two(d.hour)}:${_two(d.minute)}';
DateTime startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);
bool isSameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

Uint8List csvBytes(List<String> header, List<List<String>> rows) {
  String f(String s) => '"${s.replaceAll('"', '""')}"';
  final b = StringBuffer('\uFEFF')..write('${header.map(f).join(';')}\r\n');
  for (final r in rows) {
    b.write('${r.map(f).join(';')}\r\n');
  }
  return Uint8List.fromList(utf8.encode(b.toString()));
}

Future<Uint8List> shrinkImage(Uint8List bytes, {int width = 640}) async {
  try {
    final codec = await ui.instantiateImageCodec(bytes, targetWidth: width);
    final frame = await codec.getNextFrame();
    final data = await frame.image.toByteData(format: ui.ImageByteFormat.png);
    if (data != null) return data.buffer.asUint8List();
  } catch (_) {}
  return bytes;
}

/// Telefon raqamini xalqaro ko‘rinishga keltiradi (Uzbekiston: 998…).
String phoneDigits(String phone) {
  var d = phone.replaceAll(RegExp(r'\D'), '');
  if (d.length == 9) d = '998$d';
  return d;
}
