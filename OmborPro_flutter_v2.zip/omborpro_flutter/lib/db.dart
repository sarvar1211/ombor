import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

const _schema = <String>[
  '''CREATE TABLE products(
    id TEXT PRIMARY KEY, name TEXT NOT NULL, barcode TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '',
    cost INTEGER NOT NULL DEFAULT 0, price INTEGER NOT NULL DEFAULT 0, qty REAL NOT NULL DEFAULT 0,
    unit TEXT NOT NULL DEFAULT 'dona', min_qty REAL NOT NULL DEFAULT 0, supplier TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '', image BLOB, created INTEGER NOT NULL)''',
  '''CREATE TABLE movements(
    id TEXT PRIMARY KEY, op_id TEXT NOT NULL UNIQUE, ts INTEGER NOT NULL, kind TEXT NOT NULL, product_id TEXT,
    product_name TEXT NOT NULL, delta REAL NOT NULL, unit_price INTEGER NOT NULL, unit_cost INTEGER NOT NULL,
    note TEXT NOT NULL DEFAULT '')''',
  'CREATE INDEX idx_movements_ts ON movements(ts)',
  '''CREATE TABLE finance(
    id TEXT PRIMARY KEY, op_id TEXT NOT NULL UNIQUE, ts INTEGER NOT NULL, kind TEXT NOT NULL,
    amount INTEGER NOT NULL, title TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '')''',
  'CREATE INDEX idx_finance_ts ON finance(ts)',
  '''CREATE TABLE parties(
    id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', type TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '', created INTEGER NOT NULL)''',
  '''CREATE TABLE debts(
    id TEXT PRIMARY KEY, party_id TEXT NOT NULL, ts INTEGER NOT NULL, due INTEGER, amount INTEGER NOT NULL,
    note TEXT NOT NULL DEFAULT '', movement_id TEXT)''',
  'CREATE INDEX idx_debts_party ON debts(party_id)',
  '''CREATE TABLE payments(
    id TEXT PRIMARY KEY, op_id TEXT NOT NULL UNIQUE, debt_id TEXT NOT NULL, party_id TEXT NOT NULL,
    ts INTEGER NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '')''',
  'CREATE INDEX idx_payments_debt ON payments(debt_id)',
  'CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)',
];

Future<Database> openAppDb({String? path}) async {
  final dbPath = path ?? p.join((await getApplicationSupportDirectory()).path, 'omborpro.db');
  return openDatabase(
    dbPath,
    version: 1,
    onCreate: (db, version) async {
      for (final s in _schema) {
        await db.execute(s);
      }
    },
  );
}
