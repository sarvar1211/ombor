# OmborPro (Flutter) — Windows · Android · iOS

Bitta ilova ichida: **Ombor + Kirim-Chiqim + Qarz daftari + Dashboard**. Ma’lumotlar qurilmaning o‘zida (SQLite), internet shart emas.

## 1. Tayyorgarlik (bir marta)
1. Flutter SDK (3.24+) o‘rnating: https://docs.flutter.dev/get-started/install/windows
2. Windows ilovasi uchun: **Visual Studio 2022** + «Desktop development with C++» komponenti.
3. Android uchun: Android Studio (sizda bor). iOS faqat Mac + Xcode’da yig‘iladi.
4. `flutter doctor` — hammasi yashil bo‘lsin.

## 2. Loyihani tayyorlash
Shu papkada (pubspec.yaml turgan joyda) terminal oching:

```
flutter create . --project-name omborpro --org com.example --platforms=windows,android,ios
flutter pub get
```

(`flutter create` faqat yetishmayotgan platforma papkalarini qo‘shadi, `lib/` va `test/` ga tegmaydi.)

## 3. Ishga tushirish
- Windows: `flutter run -d windows`
- Android telefon (USB): `flutter run -d <qurilma>` yoki APK: `flutter build apk --release`
- Windows o‘rnatuvchi fayl (.exe): `flutter build windows --release` → `build\windows\x64\runner\Release\`
- Testlar: `flutter test`

## Hozirgi holat
Bor: mahsulotlar (rasm, kategoriya, ixtiyoriy kod), kirim/sotuv/qaytarish/hisobdan chiqarish/inventarizatsiya, pul kirim-chiqimi,
mijoz va yetkazib beruvchi qarz daftari (qisman/to‘liq to‘lov, muddat, «Yopilgan» holati, sotuv/xarid bilan bog‘lash),
eslatma (WhatsApp/SMS/nusxalash), dashboard + grafik, CSV eksport, zaxira nusxa (.db), Light/Dark.

Keyingi bosqichlar: PIN/Face ID + admin/xodim rollari + o‘zgarishlar tarixi, qurilmalar o‘rtasida bulutli sinxronlash,
kunlik/haftalik/oylik/yillik hisobotlar (PDF/XLSX), App Store tayyorlash.
