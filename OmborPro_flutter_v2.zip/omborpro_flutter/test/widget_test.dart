// Biznes-mantiq testlari (nomi flutter create yaratadigan standart test o‘rnini bosadi).
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:omborpro/models.dart';
import 'package:omborpro/repo.dart';
import 'package:omborpro/util.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  Future<Repo> make() async {
    final dir = Directory.systemTemp.createTempSync('omborpro_test');
    final r = Repo();
    await r.init(path: '${dir.path}/t.db');
    return r;
  }

  Future<Product> addProduct(Repo r, {double qty = 10}) async {
    await r.createProduct(Product(id: newId(), name: 'Un', cost: 8000, price: 10000, unit: 'kg'), qty);
    return r.products.first;
  }

  test('sotuv qoldiqni kamaytiradi va pul kirimini yozadi', () async {
    final r = await make();
    final p = await addProduct(r);
    await r.sell(p, 3, 10000);
    expect(r.products.first.qty, 7);
    expect(r.finance.where((e) => e.kind == FinanceKind.saleIncome).map((e) => e.amount), [30000]);
  });

  test('omborda yetmasa sotuv rad etiladi va hech narsa o‘zgarmaydi', () async {
    final r = await make();
    final p = await addProduct(r, qty: 2);
    expect(() => r.sell(p, 5, 10000), throwsA(isA<AppError>()));
    expect(r.products.first.qty, 2);
  });

  test('bir xil opId bilan amal ikki marta bajarilmaydi', () async {
    final r = await make();
    final p = await addProduct(r);
    await r.sell(p, 1, 10000, opId: 'same');
    await r.sell(p, 1, 10000, opId: 'same');
    expect(r.products.first.qty, 9);
  });

  test('500 000 so‘mlik sotuv, 200 000 to‘landi → 300 000 qarz, ombor yangilanadi', () async {
    final r = await make();
    await r.createProduct(Product(id: newId(), name: 'Tovar', cost: 40000, price: 50000), 20);
    final p = r.products.first;
    final c = await r.addParty('Ali', '+998901234567', PartyType.customer);
    await r.sell(p, 10, 50000, paid: 200000, partyId: c.id);
    expect(r.products.first.qty, 10);
    expect(r.balanceOf(c.id), 300000);
    expect(r.customersOwe, 300000);
    expect(r.finance.where((e) => e.kind == FinanceKind.saleIncome).single.amount, 200000);
  });

  test('qarzga sotishda mijoz tanlanmasa xato', () async {
    final r = await make();
    final p = await addProduct(r);
    expect(() => r.sell(p, 1, 10000, paid: 0), throwsA(isA<AppError>()));
    expect(r.products.first.qty, 10);
  });

  test('to‘lov eng eski qarzdan yopiladi; to‘liq yopilganda holat «Yopilgan»', () async {
    final r = await make();
    final c = await r.addParty('Vali', '', PartyType.customer);
    await r.addDebt(c.id, 100000);
    await r.addDebt(c.id, 50000);
    await r.pay(c.id, 120000);
    expect(r.balanceOf(c.id), 30000);
    expect(r.debtsOf(c.id).where((d) => d.isClosed).length, 1);
    await r.pay(c.id, 30000);
    expect(r.balanceOf(c.id), 0);
    expect(r.debtsOf(c.id).every((d) => d.isClosed), true);
    expect(r.finance.where((e) => e.kind == FinanceKind.debtCollected).fold(0, (s, e) => s + e.amount), 150000);
  });

  test('qoldiq qarzdan ko‘p to‘lov rad etiladi', () async {
    final r = await make();
    final c = await r.addParty('Vali', '', PartyType.customer);
    await r.addDebt(c.id, 1000);
    expect(() => r.pay(c.id, 5000), throwsA(isA<AppError>()));
    expect(r.balanceOf(c.id), 1000);
  });

  test('takroriy to‘lov (bir xil opId) ikki marta hisoblanmaydi', () async {
    final r = await make();
    final c = await r.addParty('Vali', '', PartyType.customer);
    await r.addDebt(c.id, 10000);
    await r.pay(c.id, 4000, opId: 'p1');
    await r.pay(c.id, 4000, opId: 'p1');
    expect(r.balanceOf(c.id), 6000);
  });

  test('qarzga xarid: o‘rtacha tannarx va yetkazib beruvchi qarzi', () async {
    final r = await make();
    final p = await addProduct(r); // 10 × 8000
    final s = await r.addParty('Ta’minotchi', '', PartyType.supplier);
    await r.receive(p, 10, 10000, paid: 40000, partyId: s.id);
    expect(r.products.first.cost, 9000);
    expect(r.products.first.qty, 20);
    expect(r.weOwe, 60000);
    await r.pay(s.id, 60000);
    expect(r.weOwe, 0);
    expect(r.finance.where((e) => e.kind == FinanceKind.debtPaid).single.amount, 60000);
  });

  test('foyda: qarzga sotilgani ham sotuv hisoblanadi, qarz to‘lovi foydaga ta’sir qilmaydi', () async {
    final r = await make();
    final p = await addProduct(r); // tannarx 8000
    final c = await r.addParty('Ali', '', PartyType.customer);
    await r.sell(p, 4, 10000, paid: 10000, partyId: c.id); // sotuv 40 000, tannarx 32 000
    await r.addOther(FinanceKind.otherExpense, 3000, 'Transport');
    var s = Summary.of(r.finance, r.movements);
    expect(s.profit, 40000 - 32000 - 3000);
    expect(s.income, 10000);
    await r.pay(c.id, 30000);
    s = Summary.of(r.finance, r.movements);
    expect(s.profit, 5000);
    expect(s.income, 40000);
  });

  test('inventarizatsiya farqni yozadi', () async {
    final r = await make();
    final p = await addProduct(r);
    await r.adjust(p, 8);
    expect(r.products.first.qty, 8);
    expect(r.movements.firstWhere((m) => m.kind == MovementKind.adjustment).delta, -2);
  });
}
